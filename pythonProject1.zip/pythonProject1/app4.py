# for, while

data_barang = ['tas', 'sepatu', 'pulpen']

for data_item in data_barang:
    print(data_item + '' + 'samsung')

# for number in range(0, 10):
#	print(number)
#
# nama = 'narulita dwi'
# for huruf in nama:
#	print(huruf)

# string itu adalah list, list char

index = 0
while index < 10:
    print(index + 1)

# aplikasi cmd
input_user = ''
while input_user != 'c':
    input_user = input('masukkan text : ')
    print('text anda adalah' + input_user)
