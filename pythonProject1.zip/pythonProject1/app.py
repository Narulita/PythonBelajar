nama: str = 'narulita'

umur: int = 10

tinggi: float = 160.5

def cetak_text(nama):
    print(nama)

def tambah(angka1 : int, angka2 : int) -> int :
    return angka1 + angka2

def kurang(angka1, angka2):
    pass