#if elif else

umur = 12

if umur == 12:
    print('masih muda')
elif umur == 20:
    print('dewasa')
else:
    print('tua')