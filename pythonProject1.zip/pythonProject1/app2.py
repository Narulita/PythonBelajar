mahasiswa = ['narulita', 'dwi', 'nugrahaini']
mahasiswa.append('doni')
mahasiswa.pop(0)
print(mahasiswa)

kamus = { 'buku' : 'book', 'matahari' : 'sun'}

print(kamus['buku'])

kamus.pop('buku')

kamus['bulan'] = 'moon'

print(kamus)
